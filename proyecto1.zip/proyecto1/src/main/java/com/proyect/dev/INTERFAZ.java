package com.proyect.dev;

public interface INTERFAZ {

}
